//
//  Constants.swift
//  Calculator
//
//  Created by Михаил Железовский on 15.02.2022.
//

import Foundation

struct Constants {
    static let pi = 3.1416
    static let e = 2.7182
}
